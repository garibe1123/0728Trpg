using System;
using System.Collections.Generic;
using Trpg.Data.Handouts;
using Trpg.Data.Inventory;
using Trpg.Domain.Stats;
using Trpg.UI.Handouts;
using Trpg.UI.Inventory;
using Trpg.UI.Profile;
using Trpg.UI.Skills;
using Trpg.UI.Stats;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace Trpg.Pawns
{
    /// <summary>
    /// 선택 Pawn의 하단 정보 바, 이동, 굴림, 스탯 패널과
    /// HP/MP/SAN 리소스 UI를 연결하는 씬 단위 UI Manager입니다.
    /// </summary>
    public sealed class PawnUIManager : MonoBehaviour
    {
        private const int DefaultCheckTarget =
            PawnRollStats.FallbackCheckTarget;
        private const int MinimumCheckTarget = 1;
        private const int MaximumCheckTarget = 100;

        private static readonly string[] PreferredCocAxisIds =
        {
            "coc.str",
            "coc.con",
            "coc.siz",
            "coc.dex",
            "coc.app",
            "coc.int",
            "coc.pow",
            "coc.edu"
        };

        [SerializeField] private PawnManager _pawnManager;
        [SerializeField] private PawnSystemSettings _settings;
        [SerializeField, Tooltip(
            "비어 있으면 런타임에 하단 정보 바를 자동 생성")]
        private PawnInfoBarWidget _infoBar;

        [Header("Inventory")]
        [SerializeField, Tooltip("+ 버튼에서 선택할 공용 Item Definition 카탈로그")]
        private ItemCatalogDefinition _itemCatalog;
        [SerializeField, Tooltip("19종 아이템 종류별 슬롯 아이콘 세트")]
        private InventoryIconSetDefinition _inventoryIconSet;
        [SerializeField, Tooltip("가용 무게 계산에 사용할 스탯 ID")]
        private string _inventoryCapacityStatId = "coc.str";
        [SerializeField, Min(0f), Tooltip("가용 무게 = 스탯 × 배율")]
        private float _inventoryCapacityMultiplier = 1f;
        [SerializeField, Min(0f), Tooltip("스탯을 찾지 못했을 때 가용 무게")]
        private float _inventoryFallbackCapacity;

        [Header("Handouts")]
        [SerializeField, Tooltip("시나리오에 미리 제작한 Handout Definition 카탈로그")]
        private HandoutCatalogDefinition _handoutCatalog;

        [Header("Board Dashboard")]
        [SerializeField, Tooltip(
            "활성화하면 PawnUIManager가 BoardUiStackManager를 자동 설치합니다.")]
        private bool _enableBoardDashboard = true;

        [Header("Movement")]
        [FormerlySerializedAs("_moveButton")]
        [FormerlySerializedAs("_movementButton")]
        [FormerlySerializedAs("walkButton")]
        [SerializeField, Tooltip(
            "선택한 Pawn의 이동 모드를 시작하는 걷기 버튼")]
        private Button _walkButton;

        [Header("Roll")]
        [SerializeField, Tooltip(
            "기존 판정 굴림에서 사용할 기본 능력치 ID")]
        private string _checkStatId = PawnRollStats.DefaultStatId;

        [SerializeField, Min(1), Tooltip("효과 굴림의 주사위 개수")]
        private int _effectDiceCount = 2;

        [SerializeField, Min(2), Tooltip("효과 굴림의 주사위 면수")]
        private int _effectDiceSides = 6;

        [SerializeField, Tooltip("효과 굴림 최종 합계에 더할 보정치")]
        private int _effectDiceModifier;

        [Header("Roll Result Colors")]
        [SerializeField] private Color _criticalColor =
            new Color(0.20f, 0.95f, 0.38f);
        [SerializeField] private Color _successColor =
            new Color(0.24f, 0.84f, 1f);
        [SerializeField] private Color _failureColor =
            new Color(1f, 0.36f, 0.28f);
        [SerializeField] private Color _fumbleColor = Color.black;
        [SerializeField] private Color _effectColor =
            new Color(1f, 0.78f, 0.22f);

        private PawnRollService _rollService;
        private PlayerStatState _boundStatState;
        private PlayerSkillState _boundSkillState;
        private PlayerInventoryState _boundInventoryState;
        private PawnInventoryWidget _inventoryWidget;
        private PawnProfileState _boundProfileState;
        private PawnProfileWidget _profileWidget;
        private PublicHandoutState _publicHandoutState;
        private PublicHandoutWidget _handoutWidget;
        private Button _handoutButton;
        private RectTransform _handoutButtonRect;
        private string _boundDisplayName;
        private Sprite _boundPortrait;
        private bool _isRollInProgress;
        private BoardUiStackManager _boardStackManager;
        private TRPGNetworkGameManager _networkGameManager;
        private bool _deferredStatRefresh;
        private bool _deferredProfileRefresh;

        public PawnInfoBarWidget InfoBar => _infoBar;
        public PawnManager PawnManager => _pawnManager;
        public PlayerStatState BoundStatState => _boundStatState;
        public PlayerSkillState BoundSkillState => _boundSkillState;
        public PlayerInventoryState BoundInventoryState => _boundInventoryState;
        public PawnProfileState BoundProfileState => _boundProfileState;
        public string BoundDisplayName => _boundDisplayName;
        public Sprite BoundPortrait => _boundPortrait;
        public bool HasBoardStack => _boardStackManager != null;
        public int EffectDiceCount => _effectDiceCount;
        public int EffectDiceSides => _effectDiceSides;
        public int EffectDiceModifier => _effectDiceModifier;

        public void ConfigureNetworkManager(
            TRPGNetworkGameManager networkGameManager)
        {
            _networkGameManager = networkGameManager;
        }

        public void FlushPendingEdits()
        {
            _infoBar?.FlushPendingStatEdits();
            _profileWidget?.FlushPendingEdit();
        }

        public void RegisterBoardStack(BoardUiStackManager manager)
        {
            _boardStackManager = manager;
            _inventoryWidget?.Hide();
            _profileWidget?.Hide();
            _infoBar?.SetBoardStackMode(manager != null);
        }

        public void UnregisterBoardStack(BoardUiStackManager manager)
        {
            if (_boardStackManager != manager)
                return;

            HideInventoryFromBoardStack();
            HideProfileFromBoardStack();
            _boardStackManager = null;
            _infoBar?.SetBoardStackMode(false);
        }

        public bool ShowInventoryInBoardStack(RectTransform host)
        {
            if (host == null || _boundInventoryState == null)
                return false;

            EnsureInventoryWidget();
            if (_inventoryWidget == null)
                return false;

            RefreshInventoryUi();
            _inventoryWidget.SetEmbeddedMode(host, true);
            _inventoryWidget.Show();
            return true;
        }

        public void HideInventoryFromBoardStack()
        {
            if (_inventoryWidget == null)
                return;
            _inventoryWidget.Hide();
            _inventoryWidget.SetEmbeddedMode(null, false);
        }

        public bool ShowProfileInBoardStack(RectTransform host)
        {
            if (host == null || _boundProfileState == null)
                return false;

            EnsureProfileWidget();
            if (_profileWidget == null)
                return false;

            _profileWidget.Bind(_boundProfileState, _boundDisplayName);
            _profileWidget.SetEmbeddedMode(host, true);
            _profileWidget.Show(null);
            return true;
        }

        public void HideProfileFromBoardStack()
        {
            if (_profileWidget == null)
                return;
            _profileWidget.FlushPendingEdit();
            _profileWidget.Hide();
            _profileWidget.SetEmbeddedMode(null, false);
        }

        private void Awake()
        {
            if (_pawnManager == null || _settings == null)
            {
                Debug.LogError(
                    $"[{name}] PawnUIManager 필수 참조가 비어 있습니다.",
                    this);
                enabled = false;
                return;
            }

            if (_infoBar == null)
            {
                _infoBar = PawnInfoBarWidget.CreateRuntime(_settings);
            }

            var seed = unchecked(
                Environment.TickCount * 397 ^ GetInstanceID());
            _rollService = new PawnRollService(seed);
            _publicHandoutState = PublicHandoutState.ResolveOrCreate(
                gameObject,
                _handoutCatalog);
            EnsureBoardDashboard();
        }

        private void EnsureBoardDashboard()
        {
            if (!_enableBoardDashboard)
                return;

#if UNITY_2023_1_OR_NEWER
            var existing = UnityEngine.Object.FindObjectsByType<
                BoardUiStackManager>(
                FindObjectsInactive.Include,
                FindObjectsSortMode.None);
#else
            var existing = UnityEngine.Object.FindObjectsOfType<
                BoardUiStackManager>(true);
#endif
            for (var index = 0; index < existing.Length; index++)
            {
                var manager = existing[index];
                if (manager != null && manager.gameObject != gameObject)
                    manager.enabled = false;
            }

            var local = GetComponent<BoardUiStackManager>();
            if (local == null)
                local = gameObject.AddComponent<BoardUiStackManager>();
            local.Configure(this);
        }

        private void OnEnable()
        {
            if (_pawnManager == null || _infoBar == null)
            {
                return;
            }

            _pawnManager.InteractiveSelectionChanged +=
                HandleInteractiveSelectionChanged;
            _pawnManager.MovementManager.MovementBudgetChanged +=
                HandleMovementBudgetChanged;
            _pawnManager.MovementManager.PathPreviewChanged +=
                HandlePathPreviewChanged;
            _pawnManager.MovementManager.MovementRangeChanged +=
                HandleMovementRangeChanged;

            _infoBar.CloseRequested += HandleCloseRequested;
            _infoBar.MoveRequested += StartWalking;
            _infoBar.CheckRollRequested += HandleCheckRollRequested;
            _infoBar.EffectRollRequested += HandleEffectRollRequested;
            _infoBar.RollPresentationCompleted +=
                HandleRollPresentationCompleted;
            _infoBar.StatValueEditRequested +=
                HandleStatValueEditRequested;
            _infoBar.PlayerSkillAddRequested +=
                HandleSkillAddRequested;
            _infoBar.PlayerSkillNameEditRequested +=
                HandleSkillNameEditRequested;
            _infoBar.PlayerSkillRegularEditRequested +=
                HandleSkillRegularEditRequested;
            _infoBar.PlayerSkillRemoveRequested +=
                HandleSkillRemoveRequested;
            _infoBar.InventoryRequested +=
                HandleInventoryRequested;
            _infoBar.ProfileRequested +=
                HandleProfileRequested;

            BindHandoutSystem();
            BindWalkButton();
            HandleInteractiveSelectionChanged(
                _pawnManager.SelectedInteractive);
        }

        private void LateUpdate()
        {
            if (_deferredStatRefresh &&
                (_infoBar == null || !_infoBar.HasActiveStatEdit))
            {
                _deferredStatRefresh = false;
                RefreshStatUi();
                RefreshInventoryUi();
            }

            if (_deferredProfileRefresh &&
                (_profileWidget == null ||
                 !_profileWidget.HasActiveEdit))
            {
                _deferredProfileRefresh = false;
                if (_profileWidget != null &&
                    _profileWidget.IsVisible)
                {
                    _profileWidget.RefreshFromState();
                }
            }
        }

        private void OnDisable()
        {
            FlushPendingEdits();
            if (_pawnManager != null)
            {
                _pawnManager.InteractiveSelectionChanged -=
                    HandleInteractiveSelectionChanged;
                _pawnManager.MovementManager.MovementBudgetChanged -=
                    HandleMovementBudgetChanged;
                _pawnManager.MovementManager.PathPreviewChanged -=
                    HandlePathPreviewChanged;
                _pawnManager.MovementManager.MovementRangeChanged -=
                    HandleMovementRangeChanged;
            }

            if (_infoBar != null)
            {
                _infoBar.CloseRequested -= HandleCloseRequested;
                _infoBar.MoveRequested -= StartWalking;
                _infoBar.CheckRollRequested -= HandleCheckRollRequested;
                _infoBar.EffectRollRequested -= HandleEffectRollRequested;
                _infoBar.RollPresentationCompleted -=
                    HandleRollPresentationCompleted;
                _infoBar.StatValueEditRequested -=
                    HandleStatValueEditRequested;
                _infoBar.PlayerSkillAddRequested -=
                    HandleSkillAddRequested;
                _infoBar.PlayerSkillNameEditRequested -=
                    HandleSkillNameEditRequested;
                _infoBar.PlayerSkillRegularEditRequested -=
                    HandleSkillRegularEditRequested;
                _infoBar.PlayerSkillRemoveRequested -=
                    HandleSkillRemoveRequested;
                _infoBar.InventoryRequested -=
                    HandleInventoryRequested;
                _infoBar.ProfileRequested -=
                    HandleProfileRequested;
                _infoBar.Hide();
            }

            UnbindStatState();
            UnbindSkillState();
            UnbindInventoryState();
            if (_boardStackManager != null)
                HideInventoryFromBoardStack();
            else
                _inventoryWidget?.Hide();
            UnbindProfileState();
            if (_boardStackManager != null)
                HideProfileFromBoardStack();
            else
                _profileWidget?.Hide();
            UnbindHandoutSystem();
            _handoutWidget?.Hide();
            if (_handoutButton != null)
                _handoutButton.gameObject.SetActive(false);
            UnbindWalkButton();
            _isRollInProgress = false;
            PlayerStatState.SetActive(null);
        }

        private void OnDestroy()
        {
            if (_inventoryWidget != null)
            {
                Destroy(_inventoryWidget.gameObject);
                _inventoryWidget = null;
            }

            if (_profileWidget != null)
            {
                _profileWidget.CloseRequested -=
                    HandleProfileCloseRequested;
                _profileWidget.Applied -=
                    HandleProfileApplied;
                _profileWidget.ValueEditRequested -=
                    HandleProfileValueEditRequested;
                Destroy(_profileWidget.gameObject);
                _profileWidget = null;
            }

            if (_handoutWidget != null)
            {
                Destroy(_handoutWidget.gameObject);
                _handoutWidget = null;
            }

            if (_handoutButton != null)
            {
                Destroy(_handoutButton.gameObject);
                _handoutButton = null;
                _handoutButtonRect = null;
            }
        }

        private void HandleCloseRequested()
        {
            FlushPendingEdits();
            _inventoryWidget?.Hide();
            _profileWidget?.Hide();
            _pawnManager.ClearSelection();
        }

        private void HandleInteractiveSelectionChanged(
            InteractivePawn pawn)
        {
            FlushPendingEdits();
            _deferredStatRefresh = false;
            _deferredProfileRefresh = false;
            UnbindStatState();
            UnbindSkillState();
            UnbindInventoryState();
            if (_boardStackManager != null)
                HideInventoryFromBoardStack();
            else
                _inventoryWidget?.Hide();
            UnbindProfileState();
            if (_boardStackManager != null)
                HideProfileFromBoardStack();
            else
                _profileWidget?.Hide();

            if (pawn == null || pawn.Definition == null)
            {
                PlayerStatState.SetActive(null);
                _infoBar.Unbind();
                RefreshWalkButton(null);
                RefreshRollButtons(null);
                return;
            }

            PlayerStatState.SetActiveFrom(pawn.gameObject);

            var definition = pawn.Definition;
            var displayName =
                string.IsNullOrWhiteSpace(definition.DisplayName)
                    ? pawn.name
                    : definition.DisplayName;
            var infoData = new PawnInfoBarData(
                displayName,
                definition.Description,
                definition.Portrait,
                definition.MovementScore);

            _infoBar.Bind(infoData);
            _infoBar.SetProfileButtonEnabled(IsPlayerPawn(pawn));

            var statState = ResolveStatState(pawn);
            if (statState != null)
            {
                BindStatState(
                    statState,
                    displayName,
                    definition.Portrait);
                BindSkillState(
                    PlayerSkillState.ResolveOrCreate(
                        pawn.gameObject,
                        definition));
                RefreshStatUi();
            }
            else
            {
                _infoBar.ClearStats();
            }

            BindInventoryState(
                PlayerInventoryState.ResolveOrCreate(
                    pawn.gameObject,
                    definition,
                    _itemCatalog));

            if (IsPlayerPawn(pawn))
            {
                BindProfileState(
                    PawnProfileState.ResolveOrCreate(
                        pawn.gameObject,
                        definition));
            }

            RefreshMovementBudget(pawn);
            RefreshWalkButton(pawn);
            RefreshRollButtons(pawn);
        }

        public void StartWalking()
        {
            if (_pawnManager == null)
            {
                return;
            }

            _pawnManager.SetMovementMode(true);
            RefreshWalkButton(_pawnManager.SelectedInteractive);
        }

        public void SetCheckStatId(string statId)
        {
            _checkStatId = string.IsNullOrWhiteSpace(statId)
                ? PawnRollStats.DefaultStatId
                : statId.Trim();
            RefreshRollButtons(_pawnManager.SelectedInteractive);
        }

        public void SetEffectDiceExpression(
            int diceCount,
            int sides,
            int modifier = 0)
        {
            _effectDiceCount = Mathf.Clamp(
                diceCount,
                1,
                PawnRollService.MaximumDiceCount);
            _effectDiceSides = Mathf.Clamp(
                sides,
                2,
                PawnRollService.MaximumDiceSides);
            _effectDiceModifier = modifier;
            RefreshRollButtons(_pawnManager.SelectedInteractive);
        }

        public void RollEffectFromBoardStack(
            PawnEffectRollRequest request)
        {
            HandleEffectRollRequested(request);
        }

        private void BindStatState(
            PlayerStatState statState,
            string displayName,
            Sprite portrait)
        {
            if (statState == null)
            {
                _infoBar.ClearStats();
                return;
            }

            if (!statState.IsInitialized)
            {
                statState.Initialize();
            }

            if (!statState.IsInitialized)
            {
                _infoBar.ClearStats();
                return;
            }

            _boundStatState = statState;
            _boundDisplayName = displayName;
            _boundPortrait = portrait;
            _boundStatState.Changed -= HandleBoundStatStateChanged;
            _boundStatState.Changed += HandleBoundStatStateChanged;
        }

        private void UnbindStatState()
        {
            if (_boundStatState != null)
            {
                _boundStatState.Changed -= HandleBoundStatStateChanged;
            }

            _boundStatState = null;
            _boundDisplayName = string.Empty;
            _boundPortrait = null;
        }

        private void BindSkillState(PlayerSkillState skillState)
        {
            if (skillState == null)
                return;

            if (!skillState.IsInitialized)
                skillState.Initialize();
            if (!skillState.IsInitialized)
                return;

            _boundSkillState = skillState;
            _boundSkillState.Changed -= HandleBoundSkillStateChanged;
            _boundSkillState.Changed += HandleBoundSkillStateChanged;
        }

        private void UnbindSkillState()
        {
            if (_boundSkillState != null)
            {
                _boundSkillState.Changed -= HandleBoundSkillStateChanged;
            }

            _boundSkillState = null;
        }

        private void BindInventoryState(
            PlayerInventoryState inventoryState)
        {
            if (inventoryState == null)
                return;

            if (!inventoryState.IsInitialized)
                inventoryState.Initialize();
            if (!inventoryState.IsInitialized)
                return;

            _boundInventoryState = inventoryState;
            _boundInventoryState.Changed -=
                HandleBoundInventoryStateChanged;
            _boundInventoryState.Changed +=
                HandleBoundInventoryStateChanged;
        }

        private void UnbindInventoryState()
        {
            if (_boundInventoryState != null)
            {
                _boundInventoryState.Changed -=
                    HandleBoundInventoryStateChanged;
            }

            _boundInventoryState = null;
        }

        private void BindProfileState(PawnProfileState profileState)
        {
            if (profileState == null)
                return;

            if (!profileState.IsInitialized)
                profileState.Initialize();
            if (!profileState.IsInitialized)
                return;

            _boundProfileState = profileState;
            _boundProfileState.Changed -=
                HandleBoundProfileStateChanged;
            _boundProfileState.Changed +=
                HandleBoundProfileStateChanged;
        }

        private void UnbindProfileState()
        {
            if (_boundProfileState != null)
            {
                _boundProfileState.Changed -=
                    HandleBoundProfileStateChanged;
            }

            _boundProfileState = null;
        }

        private void HandleBoundProfileStateChanged()
        {
            if (_profileWidget == null ||
                !_profileWidget.IsVisible)
            {
                return;
            }

            if (_profileWidget.HasActiveEdit)
            {
                _deferredProfileRefresh = true;
                return;
            }

            _deferredProfileRefresh = false;
            _profileWidget.RefreshFromState();
        }

        private void HandleBoundInventoryStateChanged()
        {
            RefreshInventoryUi();
        }

        private void HandleBoundStatStateChanged()
        {
            if (_infoBar != null && _infoBar.HasActiveStatEdit)
            {
                _deferredStatRefresh = true;
                return;
            }

            _deferredStatRefresh = false;
            RefreshStatUi();
            RefreshInventoryUi();
        }

        private void HandleBoundSkillStateChanged()
        {
            RefreshStatUi();
        }

        private void HandleStatValueEditRequested(
            string statId,
            double value)
        {
            if (_boundStatState == null ||
                string.IsNullOrWhiteSpace(statId))
            {
                return;
            }

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;

            var authority = TRPGSessionAuthority.Instance;
            var shouldRouteClientStat =
                (_networkGameManager != null &&
                 _networkGameManager.ShouldRouteClientStatChange) ||
                (authority != null &&
                 authority.ShouldRouteClientStatChange);

            if (shouldRouteClientStat)
            {
                var requested =
                    _networkGameManager != null &&
                    _networkGameManager.RequestStatChange(
                        pawn,
                        statId,
                        value);

                if (!requested && authority != null)
                {
                    requested = authority.RequestStatChange(
                        pawn,
                        statId,
                        value);
                }

                if (!requested)
                    RefreshStatUi();

                return;
            }

            var previous = TryGetDisplayedStatValue(
                _boundStatState,
                statId,
                out var previousValue)
                    ? previousValue
                    : value;

            if (!_boundStatState.TrySetAuthoritativeDisplayedValue(
                    statId,
                    value))
            {
                Debug.LogWarning(
                    $"[{name}] 표시 스탯 값을 변경하지 못했습니다. " +
                    $"StatId={statId}, Value={value}",
                    _boundStatState);
                RefreshStatUi();
                return;
            }

            var current = TryGetDisplayedStatValue(
                _boundStatState,
                statId,
                out var currentValue)
                    ? currentValue
                    : value;

            var sessionAuthority =
                TRPGSessionAuthority.Instance;

            if (sessionAuthority != null)
            {
                sessionAuthority.PublishHostStatChange(
                    pawn,
                    statId,
                    previous,
                    current);
            }
            else
            {
                _networkGameManager?.PublishHostStatChange(
                    pawn,
                    statId,
                    previous,
                    current);
            }
        }

        private static bool TryGetDisplayedStatValue(
            PlayerStatState statState,
            string statId,
            out double value)
        {
            value = 0d;
            if (statState?.Runtime == null ||
                string.IsNullOrWhiteSpace(statId))
            {
                return false;
            }

            try
            {
                value = statState.Runtime.GetNumber(statId);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        private void HandleSkillAddRequested(
            PawnSkillAddRequest request)
        {
            if (_boundSkillState == null)
                return;

            string error;
            var succeeded = string.IsNullOrWhiteSpace(request.SkillId)
                ? _boundSkillState.TryAddCustom(
                    "새 스킬",
                    request.RegularValue,
                    out _,
                    out error)
                : _boundSkillState.TryAdd(
                    request.SkillId,
                    request.RegularValue,
                    out error);

            if (!succeeded)
            {
                Debug.LogWarning(
                    $"[{name}] 스킬을 추가하지 못했습니다. {error}",
                    _boundSkillState);
                RefreshStatUi();
            }
        }

        private void HandleSkillNameEditRequested(
            PawnSkillNameEditRequest request)
        {
            if (_boundSkillState == null ||
                !_boundSkillState.TrySetDisplayName(
                    request.SkillId,
                    request.DisplayName))
            {
                RefreshStatUi();
            }
        }

        private void HandleSkillRegularEditRequested(
            PawnSkillRegularEditRequest request)
        {
            if (_boundSkillState == null ||
                !_boundSkillState.TrySetRegularValue(
                    request.SkillId,
                    request.RegularValue))
            {
                RefreshStatUi();
            }
        }

        private void HandleSkillRemoveRequested(
            PawnSkillRemoveRequest request)
        {
            if (_boundSkillState == null ||
                !_boundSkillState.TryRemove(request.SkillId))
            {
                RefreshStatUi();
            }
        }

        private void BindHandoutSystem()
        {
            if (_publicHandoutState == null)
            {
                _publicHandoutState = PublicHandoutState.ResolveOrCreate(
                    gameObject,
                    _handoutCatalog);
            }
            else
            {
                _publicHandoutState.Configure(_handoutCatalog);
                _publicHandoutState.Initialize();
            }

            if (_publicHandoutState != null)
            {
                _publicHandoutState.Changed -=
                    HandlePublicHandoutStateChanged;
                _publicHandoutState.Changed +=
                    HandlePublicHandoutStateChanged;
            }

            EnsureHandoutButton();
            if (_handoutButton != null)
            {
                _handoutButton.onClick.RemoveListener(
                    HandleHandoutButtonClicked);
                _handoutButton.onClick.AddListener(
                    HandleHandoutButtonClicked);
                _handoutButton.gameObject.SetActive(true);
            }
            RefreshHandoutUi();
        }

        private void UnbindHandoutSystem()
        {
            if (_publicHandoutState != null)
            {
                _publicHandoutState.Changed -=
                    HandlePublicHandoutStateChanged;
            }

            if (_handoutButton != null)
            {
                _handoutButton.onClick.RemoveListener(
                    HandleHandoutButtonClicked);
            }
        }

        private void HandlePublicHandoutStateChanged()
        {
            RefreshHandoutUi();
        }

        private void EnsureHandoutButton()
        {
            if (_handoutButton != null || _infoBar == null)
                return;

            var canvas = _infoBar.GetComponentInParent<Canvas>();
            var rootCanvas = canvas != null ? canvas.rootCanvas : null;
            if (rootCanvas == null)
            {
                Debug.LogError(
                    $"[{name}] 핸드아웃 버튼을 생성할 Root Canvas를 " +
                    "찾지 못했습니다.",
                    this);
                return;
            }

            var buttonObject = new GameObject(
                "PublicHandoutButton",
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Image),
                typeof(Button));
            _handoutButtonRect =
                buttonObject.GetComponent<RectTransform>();
            _handoutButtonRect.SetParent(rootCanvas.transform, false);
            _handoutButtonRect.anchorMin = new Vector2(1f, 0f);
            _handoutButtonRect.anchorMax = new Vector2(1f, 0f);
            _handoutButtonRect.pivot = new Vector2(1f, 0f);
            _handoutButtonRect.anchoredPosition =
                new Vector2(-24f, 24f);
            _handoutButtonRect.sizeDelta = new Vector2(148f, 46f);

            var image = buttonObject.GetComponent<Image>();
            image.color = new Color(0.07f, 0.16f, 0.20f, 0.98f);
            _handoutButton = buttonObject.GetComponent<Button>();
            _handoutButton.targetGraphic = image;
            _handoutButton.transition = Selectable.Transition.ColorTint;

            var labelObject = new GameObject(
                "Label",
                typeof(RectTransform),
                typeof(CanvasRenderer),
                typeof(Text));
            var labelRect = labelObject.GetComponent<RectTransform>();
            labelRect.SetParent(_handoutButtonRect, false);
            labelRect.anchorMin = Vector2.zero;
            labelRect.anchorMax = Vector2.one;
            labelRect.offsetMin = new Vector2(5f, 2f);
            labelRect.offsetMax = new Vector2(-5f, -2f);

            var label = labelObject.GetComponent<Text>();
            var sourceText = _infoBar.GetComponentInChildren<Text>(true);
            label.font = sourceText != null
                ? sourceText.font
                : Resources.GetBuiltinResource<Font>(
                    "LegacyRuntime.ttf");
            label.fontSize = 17;
            label.alignment = TextAnchor.MiddleCenter;
            label.color = Color.white;
            label.text = "핸드아웃";
            label.raycastTarget = false;
            buttonObject.transform.SetAsLastSibling();
        }

        private void HandleHandoutButtonClicked()
        {
            if (_publicHandoutState == null)
                return;

            EnsureHandoutWidget();
            if (_handoutWidget == null)
                return;

            if (_handoutWidget.IsVisible)
            {
                _handoutWidget.Hide();
                return;
            }

            RefreshHandoutUi();
            _handoutWidget.Show(_handoutButtonRect);
        }

        private void EnsureHandoutWidget()
        {
            if (_handoutWidget != null || _infoBar == null)
                return;

            var canvas = _infoBar.GetComponentInParent<Canvas>();
            var rootCanvas = canvas != null ? canvas.rootCanvas : null;
            if (rootCanvas == null)
            {
                Debug.LogError(
                    $"[{name}] 핸드아웃 UI를 생성할 Root Canvas를 " +
                    "찾지 못했습니다.",
                    this);
                return;
            }

            var text = _infoBar.GetComponentInChildren<Text>(true);
            _handoutWidget = PublicHandoutWidget.CreateRuntime(
                rootCanvas,
                text != null ? text.font : null);
            _handoutWidget.AddRequested +=
                HandleHandoutAddRequested;
            _handoutWidget.RemoveRequested +=
                HandleHandoutRemoveRequested;
            _handoutWidget.MoveRequested +=
                HandleHandoutMoveRequested;
            _handoutWidget.CloseRequested +=
                HandleHandoutCloseRequested;
        }

        private void HandleHandoutAddRequested(
            HandoutDefinition definition)
        {
            if (_publicHandoutState == null)
                return;

            if (!_publicHandoutState.TryAdd(
                    definition,
                    out var error))
            {
                Debug.LogWarning(
                    $"[{name}] 핸드아웃을 공개하지 못했습니다. " +
                    error,
                    this);
                RefreshHandoutUi();
            }
        }

        private void HandleHandoutRemoveRequested(string definitionId)
        {
            if (_publicHandoutState == null ||
                !_publicHandoutState.TryRemove(definitionId))
            {
                RefreshHandoutUi();
            }
        }

        private void HandleHandoutMoveRequested(
            string definitionId,
            int targetIndex)
        {
            if (_publicHandoutState == null ||
                !_publicHandoutState.TryMove(
                    definitionId,
                    targetIndex))
            {
                RefreshHandoutUi();
            }
        }

        private void HandleHandoutCloseRequested()
        {
            _handoutWidget?.Hide();
        }

        private void RefreshHandoutUi()
        {
            if (_handoutWidget == null ||
                _publicHandoutState == null)
            {
                return;
            }

            _handoutWidget.Bind(
                _publicHandoutState.Handouts,
                _handoutCatalog);
        }

        private void HandleProfileRequested()
        {
            if (_boardStackManager != null)
            {
                _boardStackManager.RequestTab(SheetTab.Profile);
                return;
            }

            if (_boundProfileState == null)
                return;

            EnsureProfileWidget();
            if (_profileWidget == null)
                return;

            if (_profileWidget.IsVisible)
            {
                _profileWidget.Hide();
                return;
            }

            _profileWidget.Bind(
                _boundProfileState,
                _boundDisplayName);
            _profileWidget.Show(_infoBar.PortraitAnchorRect);
        }

        private void EnsureProfileWidget()
        {
            if (_profileWidget != null || _infoBar == null)
                return;

            var canvas = _infoBar.GetComponentInParent<Canvas>();
            var rootCanvas = canvas != null ? canvas.rootCanvas : null;
            if (rootCanvas == null)
            {
                Debug.LogError(
                    $"[{name}] 플레이어 정보 UI를 생성할 Root Canvas를 " +
                    "찾지 못했습니다.",
                    this);
                return;
            }

            var text = _infoBar.GetComponentInChildren<Text>(true);
            _profileWidget = PawnProfileWidget.CreateRuntime(
                rootCanvas.transform as RectTransform,
                text != null ? text.font : null);
            _profileWidget.CloseRequested +=
                HandleProfileCloseRequested;
            _profileWidget.Applied +=
                HandleProfileApplied;
            _profileWidget.ValueEditRequested +=
                HandleProfileValueEditRequested;
        }

        private void HandleProfileCloseRequested()
        {
            _profileWidget?.FlushPendingEdit();
            _profileWidget?.Hide();
        }

        private void HandleProfileApplied()
        {
            _profileWidget?.FlushPendingEdit();
        }

        private void HandleProfileValueEditRequested(
            PawnProfileSection section,
            string value)
        {
            if (_boundProfileState == null)
                return;

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;
            if (pawn == null || pawn.Definition == null)
                return;

            var authority = TRPGSessionAuthority.Instance;
            var routeToHost = authority != null &&
                              authority.ShouldRouteClientProfileChange;
            if (routeToHost)
            {
                if (!authority.RequestProfileFieldChange(
                        pawn,
                        section,
                        value))
                {
                    _profileWidget?.RefreshFromState();
                }
                return;
            }

            if (!_boundProfileState.TrySetField(section, value))
            {
                _profileWidget?.RefreshFromState();
                return;
            }

            if (authority != null &&
                authority.IsLocalGameMaster &&
                authority.IsGameplayReady)
            {
                authority.PublishHostProfileFieldChange(
                    pawn,
                    section,
                    value);
            }
        }

        private void HandleInventoryRequested()
        {
            if (_boardStackManager != null)
            {
                _boardStackManager.RequestTab(SheetTab.Bag);
                return;
            }

            if (_boundInventoryState == null)
                return;

            EnsureInventoryWidget();
            if (_inventoryWidget == null)
                return;

            if (_inventoryWidget.IsVisible)
            {
                _inventoryWidget.Hide();
                return;
            }

            RefreshInventoryUi();
            _inventoryWidget.Show(_infoBar.InventoryAnchorRect);
        }

        private void EnsureInventoryWidget()
        {
            if (_inventoryWidget != null || _infoBar == null)
                return;

            var canvas = _infoBar.GetComponentInParent<Canvas>();
            var rootCanvas = canvas != null ? canvas.rootCanvas : null;
            if (rootCanvas == null)
            {
                Debug.LogError(
                    $"[{name}] 인벤토리를 생성할 Root Canvas를 찾지 못했습니다.",
                    this);
                return;
            }

            var text = _infoBar.GetComponentInChildren<Text>(true);
            _inventoryWidget = PawnInventoryWidget.CreateRuntime(
                rootCanvas.transform as RectTransform,
                text != null ? text.font : null);
            _inventoryWidget.AddRequested +=
                HandleInventoryAddRequested;
            _inventoryWidget.RemoveRequested +=
                HandleInventoryRemoveRequested;
            _inventoryWidget.QuantityChangedRequested +=
                HandleInventoryQuantityChangedRequested;
            _inventoryWidget.MoveRequested +=
                HandleInventoryMoveRequested;
            _inventoryWidget.CloseRequested +=
                HandleInventoryCloseRequested;
        }

        private void HandleInventoryAddRequested(
            InventoryItemDraft draft)
        {
            if (_boundInventoryState == null)
                return;

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;
            var authority = TRPGSessionAuthority.Instance;

            if (ShouldRouteClientInventory(authority))
            {
                var requested =
                    _networkGameManager != null &&
                    _networkGameManager.RequestInventoryAdd(
                        pawn,
                        draft);

                if (!requested && authority != null)
                {
                    requested = authority.RequestInventoryAdd(
                        pawn,
                        draft);
                }

                if (!requested)
                    RefreshInventoryUi();
                return;
            }

            string error;
            string runtimeId;
            var succeeded = draft.Definition != null
                ? _boundInventoryState.TryAdd(
                    draft.Definition,
                    draft.Quantity,
                    out runtimeId,
                    out error)
                : _boundInventoryState.TryAddCustom(
                    draft.Type,
                    draft.DisplayName,
                    draft.Quantity,
                    draft.UnitWeight,
                    out runtimeId,
                    out error);

            if (!succeeded)
            {
                Debug.LogWarning(
                    $"[{name}] 아이템을 추가하지 못했습니다. {error}",
                    _boundInventoryState);
                RefreshInventoryUi();
                return;
            }

            var itemName = draft.Definition != null
                ? draft.Definition.DisplayName
                : draft.DisplayName;
            PublishHostInventoryChange(
                authority,
                pawn,
                "아이템 추가",
                $"{itemName} ×{Mathf.Max(1, draft.Quantity)} 추가");
        }

        private void HandleInventoryRemoveRequested(string runtimeId)
        {
            if (_boundInventoryState == null)
                return;

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;
            var authority = TRPGSessionAuthority.Instance;

            if (ShouldRouteClientInventory(authority))
            {
                var requested =
                    _networkGameManager != null &&
                    _networkGameManager.RequestInventoryRemove(
                        pawn,
                        runtimeId);

                if (!requested && authority != null)
                {
                    requested = authority.RequestInventoryRemove(
                        pawn,
                        runtimeId);
                }

                if (!requested)
                    RefreshInventoryUi();
                return;
            }

            var displayName = ResolveInventoryItemName(runtimeId);
            if (!_boundInventoryState.TryRemove(runtimeId))
            {
                RefreshInventoryUi();
                return;
            }

            PublishHostInventoryChange(
                authority,
                pawn,
                "아이템 제거",
                $"{displayName} 제거");
        }

        private void HandleInventoryQuantityChangedRequested(
            string runtimeId,
            int quantity)
        {
            if (_boundInventoryState == null)
                return;

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;
            var authority = TRPGSessionAuthority.Instance;

            if (ShouldRouteClientInventory(authority))
            {
                var requested =
                    _networkGameManager != null &&
                    _networkGameManager.RequestInventoryQuantity(
                        pawn,
                        runtimeId,
                        quantity);

                if (!requested && authority != null)
                {
                    requested = authority.RequestInventoryQuantity(
                        pawn,
                        runtimeId,
                        quantity);
                }

                if (!requested)
                    RefreshInventoryUi();
                return;
            }

            var displayName = ResolveInventoryItemName(runtimeId);
            var previousQuantity =
                ResolveInventoryItemQuantity(runtimeId);
            if (!_boundInventoryState.TrySetQuantity(
                    runtimeId,
                    quantity))
            {
                RefreshInventoryUi();
                return;
            }

            PublishHostInventoryChange(
                authority,
                pawn,
                "아이템 수량",
                $"{displayName} {previousQuantity} → " +
                $"{Mathf.Max(1, quantity)}");
        }

        private void HandleInventoryMoveRequested(
            string runtimeId,
            int targetIndex)
        {
            if (_boundInventoryState == null)
                return;

            var pawn = _pawnManager != null
                ? _pawnManager.SelectedInteractive
                : null;
            var authority = TRPGSessionAuthority.Instance;

            if (ShouldRouteClientInventory(authority))
            {
                var requested =
                    _networkGameManager != null &&
                    _networkGameManager.RequestInventoryMove(
                        pawn,
                        runtimeId,
                        targetIndex);

                if (!requested && authority != null)
                {
                    requested = authority.RequestInventoryMove(
                        pawn,
                        runtimeId,
                        targetIndex);
                }

                if (!requested)
                    RefreshInventoryUi();
                return;
            }

            var displayName = ResolveInventoryItemName(runtimeId);
            if (!_boundInventoryState.TryMove(
                    runtimeId,
                    targetIndex))
            {
                RefreshInventoryUi();
                return;
            }

            PublishHostInventoryChange(
                authority,
                pawn,
                "아이템 정렬",
                $"{displayName} → 슬롯 {targetIndex + 1}");
        }

        private bool ShouldRouteClientInventory(
            TRPGSessionAuthority authority)
        {
            return (_networkGameManager != null &&
                    _networkGameManager
                        .ShouldRouteClientInventoryChange) ||
                   (authority != null &&
                    authority.ShouldRouteClientInventoryChange);
        }

        private void PublishHostInventoryChange(
            TRPGSessionAuthority authority,
            InteractivePawn pawn,
            string title,
            string detail)
        {
            if (_networkGameManager != null)
            {
                _networkGameManager.PublishHostInventorySnapshot(
                    pawn,
                    title,
                    detail);
                return;
            }

            authority?.PublishHostInventorySnapshot(
                pawn,
                title,
                detail);
        }

        private string ResolveInventoryItemName(string runtimeId)
        {
            if (_boundInventoryState == null)
                return "아이템";

            var items = _boundInventoryState.Items;
            for (var index = 0; index < items.Count; index++)
            {
                if (string.Equals(
                        items[index].RuntimeId,
                        runtimeId,
                        StringComparison.Ordinal))
                {
                    return items[index].DisplayName;
                }
            }

            return "아이템";
        }

        private int ResolveInventoryItemQuantity(string runtimeId)
        {
            if (_boundInventoryState == null)
                return 0;

            var items = _boundInventoryState.Items;
            for (var index = 0; index < items.Count; index++)
            {
                if (string.Equals(
                        items[index].RuntimeId,
                        runtimeId,
                        StringComparison.Ordinal))
                {
                    return items[index].Quantity;
                }
            }

            return 0;
        }

        private void HandleInventoryCloseRequested()
        {
            _inventoryWidget?.Hide();
        }

        private void RefreshInventoryUi()
        {
            if (_inventoryWidget == null ||
                _boundInventoryState == null)
            {
                return;
            }

            var capacity = _boundInventoryState.CalculateCapacity(
                _boundStatState,
                _inventoryCapacityStatId,
                _inventoryCapacityMultiplier,
                _inventoryFallbackCapacity);
            _inventoryWidget.Bind(
                _boundInventoryState.Items,
                _boundInventoryState.CurrentWeight,
                capacity,
                _itemCatalog,
                _inventoryIconSet);
        }

        private static bool IsPlayerPawn(InteractivePawn pawn)
        {
            var definition = pawn != null ? pawn.Definition : null;
            return definition != null &&
                   definition.Kind == InteractivePawnKind.Moveable &&
                   definition.MoveableKind == MoveablePawnKind.Player;
        }

        private void RefreshStatUi()
        {
            if (_boundStatState == null ||
                !_boundStatState.IsInitialized ||
                _boundStatState.Runtime == null)
            {
                _infoBar.ClearStats();
                return;
            }

            try
            {
                var data = BuildStatPanelData(
                    _boundStatState.Runtime,
                    _boundSkillState,
                    _boundDisplayName,
                    _boundPortrait);
                _infoBar.SetStats(data);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception, this);
                _infoBar.ClearStats();
            }
        }

        private static PawnStatPanelData BuildStatPanelData(
            StatRuntimeState runtime,
            PlayerSkillState skillState,
            string displayName,
            Sprite portrait)
        {
            var definitions = new List<IStatDefinition>(
                runtime.Template.Stats);
            definitions.Sort(
                (left, right) =>
                    left.SortOrder.CompareTo(right.SortOrder));

            var resourceIds = new HashSet<string>(
                StringComparer.Ordinal);
            var resources = new List<PawnResourceValueData>(3);

            TryAddResource(
                runtime,
                StatRole.HealthCurrent,
                StatRole.HealthMax,
                "체력",
                resources,
                resourceIds);
            TryAddResource(
                runtime,
                StatRole.SanityCurrent,
                StatRole.SanityMax,
                "이성",
                resources,
                resourceIds);
            TryAddResource(
                runtime,
                StatRole.MagicCurrent,
                StatRole.MagicMax,
                "마력",
                resources,
                resourceIds);

            var axes = BuildAxes(
                runtime,
                definitions,
                resourceIds);
            var entries = BuildEntries(
                runtime,
                definitions,
                resourceIds);

            var skills = BuildSkillValues(skillState);

            return new PawnStatPanelData(
                displayName,
                portrait,
                axes,
                entries,
                resources,
                skills,
                Array.Empty<PawnSkillOptionData>(),
                skillState != null && skillState.IsInitialized);
        }

        private static List<PawnSkillValueData> BuildSkillValues(
            PlayerSkillState skillState)
        {
            var result = new List<PawnSkillValueData>();
            if (skillState == null || !skillState.IsInitialized)
                return result;

            var source = skillState.Skills;
            for (var index = 0; index < source.Count; index++)
            {
                var value = source[index];
                var regular = Mathf.Clamp(
                    value.RegularValue,
                    0,
                    999);
                result.Add(
                    new PawnSkillValueData(
                        value.SkillId,
                        value.DisplayName,
                        value.Category,
                        regular,
                        regular / 2,
                        regular / 5,
                        value.UsesBaseValue,
                        value.RequiresTraining,
                        value.SortOrder));
            }

            result.Sort((left, right) =>
            {
                var order = left.SortOrder.CompareTo(right.SortOrder);
                if (order != 0)
                    return order;

                return string.Compare(
                    left.DisplayName,
                    right.DisplayName,
                    StringComparison.CurrentCulture);
            });
            return result;
        }

        private static List<PawnStatAxisData> BuildAxes(
            StatRuntimeState runtime,
            IReadOnlyList<IStatDefinition> definitions,
            ISet<string> excludedIds)
        {
            var axes = new List<PawnStatAxisData>(8);
            var usedIds = new HashSet<string>(StringComparer.Ordinal);

            for (var index = 0;
                 index < PreferredCocAxisIds.Length;
                 index++)
            {
                TryAddAxis(
                    runtime,
                    PreferredCocAxisIds[index],
                    axes,
                    usedIds,
                    excludedIds);
            }

            for (var index = 0;
                 index < definitions.Count && axes.Count < 8;
                 index++)
            {
                var definition = definitions[index];
                if (definition.Source != StatValueSource.Base)
                {
                    continue;
                }

                TryAddAxis(
                    runtime,
                    definition.Id,
                    axes,
                    usedIds,
                    excludedIds);
            }

            return axes;
        }

        private static void TryAddAxis(
            StatRuntimeState runtime,
            string statId,
            ICollection<PawnStatAxisData> destination,
            ISet<string> usedIds,
            ISet<string> excludedIds)
        {
            if (string.IsNullOrWhiteSpace(statId) ||
                usedIds.Contains(statId) ||
                excludedIds.Contains(statId) ||
                !runtime.TryGetDefinition(statId, out var definition))
            {
                return;
            }

            var value = runtime.GetNumber(statId);
            var minimum = definition.MinValue;
            var maximum = definition.MaxValue;
            if (maximum <= minimum)
            {
                maximum = Math.Max(minimum + 1d, value);
            }

            destination.Add(
                new PawnStatAxisData(
                    statId,
                    definition.DisplayName,
                    value,
                    minimum,
                    maximum));
            usedIds.Add(statId);
        }

        private static List<PawnStatEntryData> BuildEntries(
            StatRuntimeState runtime,
            IReadOnlyList<IStatDefinition> definitions,
            ISet<string> resourceIds)
        {
            var entries = new List<PawnStatEntryData>(
                definitions.Count);
            var presentation = new StatPresentationService(runtime);
            var isCocTemplate = IsCocTemplate(runtime.Template);

            for (var index = 0; index < definitions.Count; index++)
            {
                var definition = definitions[index];
                if (resourceIds.Contains(definition.Id))
                {
                    continue;
                }

                var value = runtime.GetNumber(definition.Id);
                var showsDifficulty =
                    isCocTemplate &&
                    IsD100Checkable(definition, value);
                var regular = showsDifficulty
                    ? Mathf.Clamp(
                        (int)Math.Floor(value),
                        0,
                        100)
                    : 0;
                var hard = showsDifficulty ? regular / 2 : 0;
                var extreme = showsDifficulty ? regular / 5 : 0;

                entries.Add(
                    new PawnStatEntryData(
                        definition.Id,
                        definition.DisplayName,
                        presentation.FormatValue(definition.Id),
                        value,
                        IsEditable(definition),
                        showsDifficulty,
                        regular,
                        hard,
                        extreme,
                        value,
                        0d,
                        0d,
                        definition.MinValue,
                        definition.MaxValue));
            }

            return entries;
        }

        private static bool IsCocTemplate(IStatRuleTemplate template)
        {
            if (template == null)
            {
                return false;
            }

            if (!string.IsNullOrWhiteSpace(template.Id) &&
                template.Id.IndexOf(
                    "coc",
                    StringComparison.OrdinalIgnoreCase) >= 0)
            {
                return true;
            }

            var stats = template.Stats;
            for (var index = 0; index < stats.Count; index++)
            {
                if (stats[index].Id.StartsWith(
                        "coc.",
                        StringComparison.Ordinal))
                {
                    return true;
                }
            }

            return false;
        }

        private static bool IsD100Checkable(
            IStatDefinition definition,
            double value)
        {
            if (definition == null ||
                value < 0d ||
                value > 100d)
            {
                return false;
            }

            if (definition.Source == StatValueSource.Base)
            {
                return true;
            }

            return !string.IsNullOrWhiteSpace(definition.Category) &&
                   definition.Category.IndexOf(
                       "기술",
                       StringComparison.Ordinal) >= 0;
        }

        private static void TryAddResource(
            StatRuntimeState runtime,
            StatRole currentRole,
            StatRole maximumRole,
            string label,
            ICollection<PawnResourceValueData> destination,
            ISet<string> resourceIds)
        {
            var currentId = runtime.Template.GetStatId(currentRole);
            var maximumId = runtime.Template.GetStatId(maximumRole);

            if (string.IsNullOrWhiteSpace(currentId) ||
                !runtime.TryGetDefinition(
                    currentId,
                    out var currentDefinition))
            {
                return;
            }

            if (string.IsNullOrWhiteSpace(maximumId))
            {
                maximumId = currentDefinition.MaxStatId;
            }

            var current = runtime.GetNumber(currentId);
            var maximum = current;
            var canEditMaximum = false;

            if (!string.IsNullOrWhiteSpace(maximumId) &&
                runtime.TryGetDefinition(
                    maximumId,
                    out var maximumDefinition))
            {
                maximum = runtime.GetNumber(maximumId);
                canEditMaximum = IsEditable(maximumDefinition);
                resourceIds.Add(maximumId);
            }

            destination.Add(
                new PawnResourceValueData(
                    label,
                    currentId,
                    current,
                    maximumId,
                    maximum,
                    true,
                    IsEditable(currentDefinition),
                    canEditMaximum));
            resourceIds.Add(currentId);
        }

        private static bool IsEditable(IStatDefinition definition)
        {
            if (definition == null)
                return false;

            var authority = TRPGSessionAuthority.Instance;
            var isNetworkPlayer =
                authority != null &&
                authority.IsOnline &&
                !authority.IsLocalGameMaster;

            if (!isNetworkPlayer)
            {
                return definition.Source == StatValueSource.Base ||
                       definition.Source == StatValueSource.Runtime;
            }

            if (definition.Source != StatValueSource.Runtime)
                return false;

            return definition.IsAdjustable ||
                   IsPlayerEditableCurrentStatId(definition.Id);
        }

        private static bool IsPlayerEditableCurrentStatId(
            string statId)
        {
            return string.Equals(
                       statId,
                       "coc.hp.current",
                       StringComparison.Ordinal) ||
                   string.Equals(
                       statId,
                       "coc.mp.current",
                       StringComparison.Ordinal) ||
                   string.Equals(
                       statId,
                       "coc.san.current",
                       StringComparison.Ordinal) ||
                   string.Equals(
                       statId,
                       "coc.luck.current",
                       StringComparison.Ordinal);
        }

        private static PlayerStatState ResolveStatState(
            InteractivePawn pawn)
        {
            if (pawn == null)
            {
                return null;
            }

            var state = pawn.GetComponentInParent<PlayerStatState>();
            if (state == null)
            {
                state = pawn.GetComponentInChildren<PlayerStatState>();
            }

            if (state == null)
            {
                state = PlayerStatState.ActiveState;
            }

            return state;
        }

        private void HandleMovementBudgetChanged(
            InteractivePawn pawn,
            float remainingMeters,
            float maximumMeters)
        {
            if (pawn == _pawnManager.SelectedInteractive)
            {
                _infoBar.SetMovementBudget(
                    remainingMeters,
                    maximumMeters);
            }
        }

        private void HandlePathPreviewChanged(PawnPathPreviewData data)
        {
            _infoBar.SetPathPreview(data, _pawnManager.BoardCamera);
        }

        private void HandleMovementRangeChanged(
            PawnMovementRangeData data)
        {
            _infoBar.SetMovementRange(data, _pawnManager.BoardCamera);
        }

        private void RefreshMovementBudget(InteractivePawn pawn)
        {
            if (_pawnManager.MovementManager.TryGetMovementBudget(
                    pawn,
                    out var remaining,
                    out var maximum))
            {
                _infoBar.SetMovementBudget(remaining, maximum);
            }
        }

        private void BindWalkButton()
        {
            if (_walkButton == null)
            {
                return;
            }

            _walkButton.onClick.RemoveListener(StartWalking);
            _walkButton.onClick.AddListener(StartWalking);
        }

        private void UnbindWalkButton()
        {
            if (_walkButton != null)
            {
                _walkButton.onClick.RemoveListener(StartWalking);
            }
        }

        private void RefreshWalkButton(InteractivePawn pawn)
        {
            var canMove = pawn != null && pawn.IsMoveable;
            var isActive =
                canMove &&
                _pawnManager != null &&
                _pawnManager.IsMovementModeActive &&
                _pawnManager.SelectedInteractive == pawn;

            _infoBar?.SetMovementModeState(canMove, isActive);

            if (_walkButton != null)
            {
                _walkButton.interactable = canMove;
            }
        }

        private void HandleCheckRollRequested(
            PawnCheckRollRequest request)
        {
            if (!TryBeginRoll(out var pawn))
            {
                return;
            }

            var target = ResolveCheckTarget(pawn);
            var result = _rollService.RollD100(target);
            var presentation = new PawnRollPresentationData(
                "판정 굴림",
                $"d100 / 목표 {target}",
                result.Roll,
                1,
                100,
                GetCheckResultLabel(result.Grade),
                $"굴림 {result.Roll} / 목표 {target}",
                GetCheckResultColor(result.Grade),
                1.55f);
            PawnRollLogService.RecordRoll(
                PawnRollLogKind.Check,
                pawn,
                presentation.Title,
                presentation.Expression,
                presentation.FinalValue,
                presentation.ResultLabel,
                presentation.DetailLabel);
            TRPGSessionAuthority.PublishRoll(
                pawn,
                PawnRollLogKind.Check,
                presentation);
            _infoBar.PlayRoll(presentation);
        }

        private void HandleEffectRollRequested(
            PawnEffectRollRequest request)
        {
            if (!TryBeginRoll(out var pawn))
            {
                return;
            }

            _effectDiceCount = Mathf.Clamp(
                request.DiceCount,
                1,
                PawnRollService.MaximumDiceCount);
            _effectDiceSides = Mathf.Clamp(
                request.DiceSides,
                2,
                PawnRollService.MaximumDiceSides);
            _effectDiceModifier = Mathf.Clamp(
                request.Modifier,
                -999,
                999);

            var result = _rollService.RollEffect(
                _effectDiceCount,
                _effectDiceSides,
                _effectDiceModifier);
            var presentation = new PawnRollPresentationData(
                "효과 굴림",
                result.Expression,
                result.Total,
                result.MinimumTotal,
                result.MaximumTotal,
                $"합계 {result.Total}",
                result.GetBreakdownLabel(),
                _effectColor,
                1.35f);
            PawnRollLogService.RecordRoll(
                PawnRollLogKind.Effect,
                pawn,
                presentation.Title,
                presentation.Expression,
                presentation.FinalValue,
                presentation.ResultLabel,
                presentation.DetailLabel);
            TRPGSessionAuthority.PublishRoll(
                pawn,
                PawnRollLogKind.Effect,
                presentation);
            _infoBar.PlayRoll(presentation);
        }

        private void HandleRollPresentationCompleted()
        {
            _isRollInProgress = false;
            _infoBar.SetRollButtonsEnabled(
                _pawnManager.SelectedInteractive != null &&
                _pawnManager.SelectedInteractive.Definition != null);
        }

        private bool TryBeginRoll(out InteractivePawn pawn)
        {
            pawn = _pawnManager.SelectedInteractive;
            if (_isRollInProgress ||
                pawn == null ||
                pawn.Definition == null)
            {
                return false;
            }

            _isRollInProgress = true;
            _infoBar.SetRollButtonsEnabled(false);
            return true;
        }

        private int ResolveCheckTarget(InteractivePawn pawn)
        {
            if (pawn != null &&
                pawn.TryGetComponent<PawnRollStats>(out var stats))
            {
                return stats.GetCheckTarget(_checkStatId);
            }

            return DefaultCheckTarget;
        }

        private void RefreshRollButtons(InteractivePawn pawn)
        {
            if (_infoBar == null)
            {
                return;
            }

            _isRollInProgress = false;
            _infoBar.CancelRollPresentation();

            var hasPawn = pawn != null && pawn.Definition != null;
            _infoBar.SetRollButtonsEnabled(hasPawn);
            if (!hasPawn)
            {
                return;
            }

            var target = Mathf.Clamp(
                ResolveCheckTarget(pawn),
                MinimumCheckTarget,
                MaximumCheckTarget);
            var effectExpression = PawnRollService.FormatExpression(
                _effectDiceCount,
                _effectDiceSides,
                _effectDiceModifier);

            // 판정 입력창의 목표값을 강제로 다시 밀어 넣지 않는다.
            // 잘못 추가된 별도 판정 Overlay도 이 Manager에서 생성하지 않는다.
            _infoBar.SetRollButtonLabels(
                $"판정 굴림\nD100 ≤ {target}",
                $"효과 굴림\n{effectExpression}");
        }

        private Color GetCheckResultColor(CheckRollGrade grade)
        {
            switch (grade)
            {
                case CheckRollGrade.Critical:
                    return _criticalColor;
                case CheckRollGrade.Fumble:
                    return _fumbleColor;
                case CheckRollGrade.ExtremeSuccess:
                case CheckRollGrade.HardSuccess:
                case CheckRollGrade.Success:
                    return _successColor;
                default:
                    return _failureColor;
            }
        }

        private static string GetCheckResultLabel(CheckRollGrade grade)
        {
            switch (grade)
            {
                case CheckRollGrade.Critical:
                    return "대성공";
                case CheckRollGrade.ExtremeSuccess:
                    return "극단적 성공";
                case CheckRollGrade.HardSuccess:
                    return "어려운 성공";
                case CheckRollGrade.Success:
                    return "성공";
                case CheckRollGrade.Fumble:
                    return "대실패";
                default:
                    return "실패";
            }
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            _effectDiceCount = Mathf.Clamp(
                _effectDiceCount,
                1,
                PawnRollService.MaximumDiceCount);
            _effectDiceSides = Mathf.Clamp(
                _effectDiceSides,
                2,
                PawnRollService.MaximumDiceSides);
            if (string.IsNullOrWhiteSpace(_checkStatId))
            {
                _checkStatId = PawnRollStats.DefaultStatId;
            }
        }
#endif
    }
}
