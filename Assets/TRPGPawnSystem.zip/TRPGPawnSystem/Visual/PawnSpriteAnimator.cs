using UnityEngine;

namespace Trpg.Pawns
{
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(InteractivePawn))]
    public sealed class PawnSpriteAnimator : MonoBehaviour
    {
        [SerializeField, Tooltip(
            "켜면 InteractivePawnDefinition의 기본 외형을 사용합니다.")]
        private bool _useDefinitionAppearance = true;
        [SerializeField] private PawnAppearance _appearance = PawnAppearance.Default;
        [SerializeField, Tooltip(
            "비어 있으면 PawnManager의 기본 Idle Motion을 사용합니다.")]
        private PawnIdleMotion _idleMotionOverride;

        private InteractivePawn _pawn;
        private PawnManager _manager;
        private PawnSpriteLibrary _library;
        private PawnIdleMotion _runtimeIdleMotion;
        private PawnSpriteRig _runtimeRig;
        private PawnSpriteRig _editorPreviewRig;
        private float _phase;
        private float _speedMultiplier = 1f;
        private int _lastKey = -1;
        private bool _selected;
        private Material _selectionMaterial;
        private bool _legacyHidden;

        public InteractivePawn Pawn => EnsurePawn();
        public bool UsesDefinitionAppearance => _useDefinitionAppearance;
        public PawnAppearance Appearance => ResolveAppearance();
        public PawnIdleMotion IdleMotionOverride => _idleMotionOverride;
        public PawnIdleMotion EffectiveIdleMotion =>
            _idleMotionOverride != null ? _idleMotionOverride : _runtimeIdleMotion;
        public bool IsModularEnabled =>
            EnsurePawn() != null &&
            _pawn.UsesModularSpriteMotion;
        public bool HasRuntimeRig => _runtimeRig != null;
        public bool HasRuntimeBinding =>
            _manager != null && _library != null;
        public float Phase => _phase;
        public float SpeedMultiplier => _speedMultiplier;

        public void BindRuntime(
            PawnManager manager,
            PawnSpriteLibrary library,
            PawnIdleMotion defaultIdleMotion)
        {
            _manager = manager;
            _library = library;
            _runtimeIdleMotion = defaultIdleMotion;
            _lastKey = -1;
            ResolveDeterministicTiming();
            SetLegacyRenderersHidden(IsModularEnabled);
        }

        public void UnbindRuntime()
        {
            ReleaseRuntimeRig();
            _manager = null;
            _library = null;
            _runtimeIdleMotion = null;
            _lastKey = -1;
            SetLegacyRenderersHidden(false);
        }

        public void AssignRuntimeRig(PawnSpriteRig rig)
        {
            if (_runtimeRig == rig)
                return;

            ReleaseRuntimeRig();
            _runtimeRig = rig;
            if (_runtimeRig == null)
                return;

            _runtimeRig.Assign(this, ResolveAppearance());
            SetLegacyRenderersHidden(true);
            _runtimeRig.SetSelectionMaterial(
                _selected,
                _selectionMaterial);
            _lastKey = -1;
        }

        public PawnSpriteRig DetachRuntimeRig()
        {
            var rig = _runtimeRig;
            _runtimeRig = null;
            _lastKey = -1;
            return rig;
        }

        public void ReleaseRuntimeRig()
        {
            if (_runtimeRig == null)
                return;

            var rig = _runtimeRig;
            _runtimeRig = null;
            _lastKey = -1;
            rig.Release();
        }

        public void UpdateRuntimeVisual(float time)
        {
            if (_runtimeRig == null || !IsModularEnabled)
                return;

            var position = Pawn.ModularVisualWorldPosition;
            _runtimeRig.SetWorldPosition(position);
            _runtimeRig.SetSortingBand(
                Mathf.FloorToInt(-position.y * 4f));

            var motion = EffectiveIdleMotion;
            var key = motion != null
                ? motion.EvaluateKey(time, _phase, _speedMultiplier)
                : 0;
            if (key == _lastKey)
                return;

            _lastKey = key;
            _runtimeRig.ApplyKey(motion, key);
        }

        public void ApplyAppearance(in PawnAppearance appearance)
        {
            _useDefinitionAppearance = false;
            _appearance = appearance.WithVisibleColorDefaults();
            _lastKey = -1;
            _runtimeRig?.ApplyAppearance(_appearance);
#if UNITY_EDITOR
            if (!Application.isPlaying)
                RefreshEditorPreviewFromScene();
#endif
        }

        public void ApplyDefinitionAppearance()
        {
            var pawn = EnsurePawn();
            if (pawn == null || pawn.Definition == null)
                return;

            _useDefinitionAppearance = true;
            _appearance = pawn.Definition.DefaultAppearance;
            _lastKey = -1;
            _runtimeRig?.ApplyAppearance(_appearance);
#if UNITY_EDITOR
            if (!Application.isPlaying)
                RefreshEditorPreviewFromScene();
#endif
        }

        public void SetSelected(
            bool selected,
            Material selectionMaterial)
        {
            _selected = selected;
            _selectionMaterial = selectionMaterial;
            _runtimeRig?.SetSelectionMaterial(
                selected,
                selectionMaterial);
#if UNITY_EDITOR
            _editorPreviewRig?.SetSelectionMaterial(
                selected,
                selectionMaterial);
#endif
        }

        public void RefreshRuntimeAppearance()
        {
            _lastKey = -1;
            if (_runtimeRig != null)
            {
                _runtimeRig.ApplyAppearance(ResolveAppearance());
                _runtimeRig.SetSelectionMaterial(
                    _selected,
                    _selectionMaterial);
            }
        }

        public void SetLegacyRenderersHidden(bool hidden)
        {
            _legacyHidden = hidden;
            var renderers = GetComponentsInChildren<SpriteRenderer>(true);
            for (var index = 0; index < renderers.Length; index++)
            {
                var renderer = renderers[index];
                if (renderer == null || IsEditorPreviewRenderer(renderer))
                    continue;

                renderer.forceRenderingOff = hidden;
            }
        }

#if UNITY_EDITOR
        public void RefreshEditorPreview(
            PawnSpriteLibrary library,
            PawnIdleMotion defaultIdleMotion)
        {
            if (Application.isPlaying)
                return;

            DestroyEditorPreview();
            if (!IsModularEnabled || library == null)
            {
                SetLegacyRenderersHidden(false);
                return;
            }

            _library = library;
            _runtimeIdleMotion = defaultIdleMotion;
            SetLegacyRenderersHidden(true);
            _editorPreviewRig = new PawnSpriteRig(
                library,
                transform,
                $"__PawnSpritePreview_{name}",
                HideFlags.HideAndDontSave);
            _editorPreviewRig.Assign(this, ResolveAppearance());
            _editorPreviewRig.SetWorldPosition(transform.position);
            _editorPreviewRig.SetSortingBand(
                Mathf.FloorToInt(-transform.position.y * 4f));
            _editorPreviewRig.ApplyKey(EffectiveIdleMotion, 0);
            _editorPreviewRig.SetSelectionMaterial(
                _selected,
                _selectionMaterial);
        }

        public void DestroyEditorPreview()
        {
            if (_editorPreviewRig == null)
                return;

            _editorPreviewRig.Destroy();
            _editorPreviewRig = null;
        }

        public void RefreshEditorPreviewFromScene()
        {
            var manager = FindFirstObjectByType<PawnManager>(
                FindObjectsInactive.Include);
            RefreshEditorPreview(
                manager != null ? manager.PawnSpriteLibrary : null,
                manager != null ? manager.DefaultPawnIdleMotion : null);
        }
#endif

        private InteractivePawn EnsurePawn()
        {
            if (_pawn == null)
                _pawn = GetComponent<InteractivePawn>();
            return _pawn;
        }

        private PawnAppearance ResolveAppearance()
        {
            var pawn = EnsurePawn();
            if (_useDefinitionAppearance &&
                pawn != null &&
                pawn.Definition != null)
            {
                return pawn.Definition.DefaultAppearance;
            }

            return _appearance.WithVisibleColorDefaults();
        }

        private void ResolveDeterministicTiming()
        {
            var pawn = EnsurePawn();
            var token = pawn != null ? pawn.InstanceId : string.Empty;
            var hash = StableHash(token);
            var motion = EffectiveIdleMotion;
            var duration = motion != null ? motion.Duration : 1f;
            _phase = (hash & 0xFFu) / 255f * duration;
            _speedMultiplier =
                0.9f + ((hash >> 8) & 0xFFu) / 255f * 0.2f;
        }

        private static uint StableHash(string value)
        {
            unchecked
            {
                const uint offset = 2166136261u;
                const uint prime = 16777619u;
                var hash = offset;
                if (!string.IsNullOrEmpty(value))
                {
                    for (var index = 0; index < value.Length; index++)
                    {
                        hash ^= value[index];
                        hash *= prime;
                    }
                }

                return hash;
            }
        }

        private bool IsEditorPreviewRenderer(SpriteRenderer renderer)
        {
#if UNITY_EDITOR
            if (_editorPreviewRig != null &&
                renderer.transform.IsChildOf(
                    _editorPreviewRig.RootObject.transform))
            {
                return true;
            }
#endif
            return false;
        }

        private void Awake()
        {
            EnsurePawn();
            if (Application.isPlaying)
                DestroyEditorPreviewIfPresentInPlayMode();
        }

        private void OnEnable()
        {
            EnsurePawn();
            if (Application.isPlaying && HasRuntimeBinding)
                SetLegacyRenderersHidden(IsModularEnabled);
#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                UnityEditor.EditorApplication.delayCall +=
                    DelayedEditorRefresh;
            }
#endif
        }

        private void OnDisable()
        {
            if (Application.isPlaying && _manager != null)
                _manager.ReleasePawnSpriteRig(this);
            else
                ReleaseRuntimeRig();
#if UNITY_EDITOR
            UnityEditor.EditorApplication.delayCall -=
                DelayedEditorRefresh;
            DestroyEditorPreview();
#endif
            SetLegacyRenderersHidden(false);
        }

        private void OnDestroy()
        {
            if (Application.isPlaying && _manager != null)
                _manager.ReleasePawnSpriteRig(this);
            else
                ReleaseRuntimeRig();
#if UNITY_EDITOR
            DestroyEditorPreview();
#endif
        }

        private void DestroyEditorPreviewIfPresentInPlayMode()
        {
#if UNITY_EDITOR
            DestroyEditorPreview();
#endif
        }

#if UNITY_EDITOR
        private void DelayedEditorRefresh()
        {
            if (this == null || Application.isPlaying)
                return;

            RefreshEditorPreviewFromScene();
        }

        private void OnValidate()
        {
            _appearance = _appearance.WithVisibleColorDefaults();
            if (!Application.isPlaying)
            {
                UnityEditor.EditorApplication.delayCall -=
                    DelayedEditorRefresh;
                UnityEditor.EditorApplication.delayCall +=
                    DelayedEditorRefresh;
            }
        }
#endif
    }
}
