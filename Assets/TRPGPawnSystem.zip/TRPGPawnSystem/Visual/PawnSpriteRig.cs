using System;
using UnityEngine;

namespace Trpg.Pawns
{
    public sealed class PawnSpriteRig
    {
        public const int SortingBandSize = 128;

        private readonly PawnSpriteLibrary _library;
        private readonly GameObject _rootObject;
        private readonly Transform _rootTransform;
        private readonly Transform[] _slotTransforms;
        private readonly SpriteRenderer[] _renderers;
        private readonly Material[] _defaultRendererMaterials;
        private readonly Material[] _restoredMaterials;
        private PawnAppearance _appearance;
        private bool _isSelected;
        private Material _selectionMaterial;
        private bool _isVisible;

        public PawnSpriteAnimator Owner { get; private set; }
        public GameObject RootObject => _rootObject;
        public bool IsAssigned => Owner != null;
        public bool IsVisible => _isVisible;

        public PawnSpriteRig(
            PawnSpriteLibrary library,
            Transform parent,
            string name,
            HideFlags hideFlags = HideFlags.None)
        {
            _library = library ??
                throw new ArgumentNullException(nameof(library));
            _rootObject = new GameObject(name)
            {
                hideFlags = hideFlags
            };
            _rootTransform = _rootObject.transform;
            _rootTransform.SetParent(parent, false);
            _rootTransform.localPosition = Vector3.zero;
            _rootTransform.localRotation = Quaternion.identity;
            _rootTransform.localScale = Vector3.one;

            var count = (int)PartSlot.Count;
            _slotTransforms = new Transform[count];
            _renderers = new SpriteRenderer[count];
            _defaultRendererMaterials = new Material[count];
            _restoredMaterials = new Material[count];

            CreateSlots(hideFlags);
            ApplyFixedHierarchy();
            SetVisible(false);
        }

        public void Assign(
            PawnSpriteAnimator owner,
            in PawnAppearance appearance)
        {
            Owner = owner;
            _isSelected = false;
            _selectionMaterial = null;
            ApplyAppearance(appearance);
            SetVisible(true);
        }

        public void Release()
        {
            Owner = null;
            _isSelected = false;
            _selectionMaterial = null;
            SetVisible(false);
            _rootTransform.localPosition = Vector3.zero;
            _rootTransform.localRotation = Quaternion.identity;
            _rootTransform.localScale = Vector3.one;
        }

        public void ApplyAppearance(in PawnAppearance appearance)
        {
            _appearance = appearance.WithVisibleColorDefaults();
            var paletteMaterial =
                _library.ResolvePaletteMaterial(_appearance);

            for (var slotIndex = 0;
                 slotIndex < (int)PartSlot.Count;
                 slotIndex++)
            {
                var slot = (PartSlot)slotIndex;
                var renderer = _renderers[slotIndex];
                if (renderer == null)
                    continue;

                var sprite = _library.ResolveSprite(
                    slot,
                    _appearance.GetPartId(slot),
                    _appearance.Height,
                    _appearance.BroadShoulders);

                renderer.sprite = sprite;
                renderer.enabled = sprite != null;

                var paletteChannel =
                    PawnPartSlotRules.GetPaletteChannel(slot);
                _restoredMaterials[slotIndex] =
                    paletteChannel != PaletteChannel.None &&
                    paletteMaterial != null
                        ? paletteMaterial
                        : _defaultRendererMaterials[slotIndex];
            }

            ApplyCurrentMaterials();
        }

        public void ApplyKey(
            PawnIdleMotion motion,
            int keyIndex)
        {
            for (var slotIndex = 0;
                 slotIndex < (int)PartSlot.Count;
                 slotIndex++)
            {
                var slot = (PartSlot)slotIndex;
                var target = _slotTransforms[slotIndex];
                if (target == null)
                    continue;

                var offset = Vector2Int.zero;
                if (PawnPartSlotRules.HasAnimationChannel(slot))
                {
                    var channel =
                        PawnPartSlotRules.GetAnimationChannel(slot);
                    offset = _library.GetBodyOffset(
                        _appearance.Height,
                        channel);
                    if (motion != null)
                    {
                        offset += motion.EvaluateOffset(
                            channel,
                            keyIndex);
                    }
                }

                var local = PixelSnap.PixelsToUnits(offset);
                target.localPosition = new Vector3(local.x, local.y, 0f);
                target.localRotation = Quaternion.identity;
                target.localScale = Vector3.one;
            }
        }

        public void SetWorldPosition(Vector3 worldPosition)
        {
            _rootTransform.position = PixelSnap.SnapWorld(worldPosition);
            _rootTransform.rotation = Quaternion.identity;
            _rootTransform.localScale = Vector3.one;
        }

        public void SetSortingBand(int yBand)
        {
            var baseOrder = yBand * SortingBandSize;
            for (var slotIndex = 0;
                 slotIndex < (int)PartSlot.Count;
                 slotIndex++)
            {
                var renderer = _renderers[slotIndex];
                if (renderer == null)
                    continue;

                var slot = (PartSlot)slotIndex;
                renderer.sortingOrder = baseOrder +
                    PawnPartSlotRules.GetSortingOrder(slot);
            }
        }

        public void SetSelectionMaterial(
            bool selected,
            Material selectionMaterial)
        {
            _isSelected = selected && selectionMaterial != null;
            _selectionMaterial = selectionMaterial;
            ApplyCurrentMaterials();
        }

        public void SetVisible(bool visible)
        {
            _isVisible = visible;
            _rootObject.SetActive(visible);
        }

        public void Destroy()
        {
            if (_rootObject == null)
                return;

            if (Application.isPlaying)
                UnityEngine.Object.Destroy(_rootObject);
            else
                UnityEngine.Object.DestroyImmediate(_rootObject);
        }

        private void CreateSlots(HideFlags hideFlags)
        {
            for (var slotIndex = 0;
                 slotIndex < (int)PartSlot.Count;
                 slotIndex++)
            {
                var slot = (PartSlot)slotIndex;
                var child = new GameObject(slot.ToString())
                {
                    hideFlags = hideFlags
                };
                var childTransform = child.transform;
                childTransform.SetParent(_rootTransform, false);
                childTransform.localPosition = Vector3.zero;
                childTransform.localRotation = Quaternion.identity;
                childTransform.localScale = Vector3.one;
                var renderer = child.AddComponent<SpriteRenderer>();
                renderer.enabled = false;
                _slotTransforms[slotIndex] = childTransform;
                _renderers[slotIndex] = renderer;
                _defaultRendererMaterials[slotIndex] = renderer.sharedMaterial;
            }
        }

        private void ApplyFixedHierarchy()
        {
            for (var slotIndex = 0;
                 slotIndex < (int)PartSlot.Count;
                 slotIndex++)
            {
                var slot = (PartSlot)slotIndex;
                var target = _slotTransforms[slotIndex];
                if (PawnPartSlotRules.ParentIsRigRoot(slot))
                {
                    target.SetParent(_rootTransform, false);
                }
                else
                {
                    var parentSlot =
                        PawnPartSlotRules.GetParentSlot(slot);
                    var parentIndex = (int)parentSlot;
                    var parent = parentIndex >= 0 &&
                                 parentIndex < _slotTransforms.Length
                        ? _slotTransforms[parentIndex]
                        : _rootTransform;
                    target.SetParent(parent, false);
                }

                target.localPosition = Vector3.zero;
                target.localRotation = Quaternion.identity;
                target.localScale = Vector3.one;
            }
        }

        private void ApplyCurrentMaterials()
        {
            if (_isSelected && _selectionMaterial != null)
            {
                for (var index = 0; index < _renderers.Length; index++)
                {
                    var renderer = _renderers[index];
                    if (renderer != null && renderer.enabled)
                        renderer.sharedMaterial = _selectionMaterial;
                }

                return;
            }

            RestoreMaterials();
        }

        private void RestoreMaterials()
        {
            for (var index = 0; index < _renderers.Length; index++)
            {
                var renderer = _renderers[index];
                if (renderer != null)
                    renderer.sharedMaterial = _restoredMaterials[index];
            }
        }
    }
}
