using UnityEngine;

namespace Trpg.Pawns
{
    public static class PixelSnap
    {
        public const int PixelsPerUnit = 32;
        public const float UnitsPerPixel = 1f / PixelsPerUnit;

        public static float PixelsToUnits(int pixels)
        {
            return pixels * UnitsPerPixel;
        }

        public static Vector2 PixelsToUnits(Vector2Int pixels)
        {
            return new Vector2(
                pixels.x * UnitsPerPixel,
                pixels.y * UnitsPerPixel);
        }

        public static float SnapUnit(float value)
        {
            return Mathf.Round(value * PixelsPerUnit) * UnitsPerPixel;
        }

        public static Vector2 SnapWorld(Vector2 worldPosition)
        {
            return new Vector2(
                SnapUnit(worldPosition.x),
                SnapUnit(worldPosition.y));
        }

        public static Vector3 SnapWorld(Vector3 worldPosition)
        {
            return new Vector3(
                SnapUnit(worldPosition.x),
                SnapUnit(worldPosition.y),
                0f);
        }
    }
}
