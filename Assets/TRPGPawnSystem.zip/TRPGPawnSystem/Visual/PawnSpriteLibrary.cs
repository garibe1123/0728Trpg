using System;
using System.Collections.Generic;
using UnityEngine;

namespace Trpg.Pawns
{
    public static class PawnPartSlotRules
    {
        public static bool ParentIsRigRoot(PartSlot slot)
        {
            return slot == PartSlot.Legs;
        }

        public static PartSlot GetParentSlot(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.HairBack:
                case PartSlot.Eyes:
                case PartSlot.HairFront:
                case PartSlot.Hat:
                    return PartSlot.Head;
                case PartSlot.Bottom:
                case PartSlot.Shoes:
                case PartSlot.Torso:
                    return PartSlot.Legs;
                case PartSlot.Top:
                case PartSlot.Head:
                    return PartSlot.Torso;
                default:
                    return PartSlot.Legs;
            }
        }

        public static bool HasAnimationChannel(PartSlot slot)
        {
            return slot != PartSlot.Bottom &&
                   slot != PartSlot.Top &&
                   slot != PartSlot.Hat;
        }

        public static ChannelId GetAnimationChannel(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.Legs:
                    return ChannelId.Legs;
                case PartSlot.Shoes:
                    return ChannelId.Feet;
                case PartSlot.Torso:
                    return ChannelId.Torso;
                case PartSlot.Eyes:
                    return ChannelId.Eyes;
                case PartSlot.Head:
                    return ChannelId.Head;
                case PartSlot.HairBack:
                case PartSlot.HairFront:
                    return ChannelId.Hair;
                default:
                    return ChannelId.Root;
            }
        }

        public static int GetSortingOrder(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.HairBack:
                    return 10;
                case PartSlot.Legs:
                    return 20;
                case PartSlot.Bottom:
                    return 30;
                case PartSlot.Shoes:
                    return 40;
                case PartSlot.Torso:
                    return 50;
                case PartSlot.Top:
                    return 60;
                case PartSlot.Eyes:
                    return 70;
                case PartSlot.Head:
                    return 80;
                case PartSlot.HairFront:
                    return 90;
                case PartSlot.Hat:
                    return 100;
                default:
                    return 0;
            }
        }

        public static PaletteChannel GetPaletteChannel(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.Head:
                case PartSlot.Torso:
                case PartSlot.Legs:
                    return PaletteChannel.Skin;
                case PartSlot.HairBack:
                case PartSlot.HairFront:
                    return PaletteChannel.Hair;
                case PartSlot.Eyes:
                    return PaletteChannel.Eye;
                default:
                    return PaletteChannel.None;
            }
        }

        public static bool UsesShoulderMorph(PartSlot slot)
        {
            return slot == PartSlot.Torso || slot == PartSlot.Top;
        }

        public static bool UsesHeightMorph(PartSlot slot)
        {
            return slot == PartSlot.Legs || slot == PartSlot.Bottom;
        }
    }

    [CreateAssetMenu(
        menuName = "Trpg/Pawn/Pawn Sprite Library",
        fileName = "PawnSpriteLibrary")]
    public sealed class PawnSpriteLibrary : ScriptableObject
    {
        public const int ExpectedCanvasSize = 64;
        public const int HeightPixelDelta = 2;
        public const int ShoulderPixelDelta = 2;
        public const int ShoulderCenterX = 32;
        public const int LegStretchCenterY = 18;

        private static readonly int SkinShadowId =
            Shader.PropertyToID("_SkinShadow");
        private static readonly int SkinBaseId =
            Shader.PropertyToID("_SkinBase");
        private static readonly int SkinHighlightId =
            Shader.PropertyToID("_SkinHighlight");
        private static readonly int HairShadowId =
            Shader.PropertyToID("_HairShadow");
        private static readonly int HairBaseId =
            Shader.PropertyToID("_HairBase");
        private static readonly int HairHighlightId =
            Shader.PropertyToID("_HairHighlight");
        private static readonly int EyeShadowId =
            Shader.PropertyToID("_EyeShadow");
        private static readonly int EyeBaseId =
            Shader.PropertyToID("_EyeBase");
        private static readonly int EyeHighlightId =
            Shader.PropertyToID("_EyeHighlight");

        [Header("Body - Default Shape Source")]
        [SerializeField, Tooltip(
            "기본 키·기본 어깨 기준 Torso Sprite. 넓은 어깨는 코드가 좌우 1px씩 자동 확장합니다.")]
        private Sprite _torso;

        [SerializeField, Tooltip(
            "기본 키 기준 하체 후보. 키가 크거나 작으면 코드가 중앙 고정 구간에서 ±2px 자동 변형합니다.")]
        private Sprite[] _legs = Array.Empty<Sprite>();

        [Header("Face")]
        [SerializeField] private Sprite[] _heads = Array.Empty<Sprite>();
        [SerializeField] private Sprite[] _eyes = Array.Empty<Sprite>();

        [Header("Hair")]
        [SerializeField] private Sprite[] _hairFronts = Array.Empty<Sprite>();
        [SerializeField] private Sprite[] _hairBacks = Array.Empty<Sprite>();

        [Header("Clothes - Default Shape Source")]
        [SerializeField, Tooltip(
            "기본 어깨 기준 상의. 넓은 어깨에서 Torso와 같은 방식으로 좌우 1px씩 자동 확장합니다.")]
        private Sprite[] _tops = Array.Empty<Sprite>();

        [SerializeField, Tooltip(
            "기본 키 기준 하의. 키 변화 시 Legs와 같은 방식으로 세로 ±2px 자동 변형합니다.")]
        private Sprite[] _bottoms = Array.Empty<Sprite>();

        [SerializeField] private Sprite[] _shoes = Array.Empty<Sprite>();
        [SerializeField] private Sprite[] _hats = Array.Empty<Sprite>();

        [Header("Palette")]
        [SerializeField, Tooltip(
            "인덱스 컬러 치환 Shader를 사용하는 공용 Material 템플릿")]
        private Material _paletteMaterialTemplate;

        [SerializeField, Range(0.1f, 1f)]
        private float _shadowMultiplier = 0.65f;

        [SerializeField, Range(1f, 2f)]
        private float _highlightMultiplier = 1.25f;

        [NonSerialized] private Dictionary<PaletteMaterialKey, Material>
            _paletteMaterialCache;
        [NonSerialized] private Dictionary<SpriteVariantKey, Sprite>
            _spriteVariantCache;
        [NonSerialized] private List<Texture2D> _generatedTextures;
        [NonSerialized] private HashSet<int> _unreadableWarnings;

        public Material PaletteMaterialTemplate => _paletteMaterialTemplate;
        public Sprite Torso => _torso;

        public int GetPartCount(PartSlot slot)
        {
            if (slot == PartSlot.Torso)
                return _torso != null ? 1 : 0;

            var sprites = GetPartArray(slot);
            return sprites != null ? sprites.Length : 0;
        }

        public Sprite GetPartSprite(PartSlot slot, int index)
        {
            if (slot == PartSlot.Torso)
                return index == 0 ? _torso : null;

            var sprites = GetPartArray(slot);
            if (sprites == null || index < 0 || index >= sprites.Length)
                return null;

            return sprites[index];
        }

        public bool TryGetPart(
            PartSlot slot,
            byte partId,
            out Sprite sprite)
        {
            sprite = null;
            if (partId == PawnAppearance.NonePartId)
                return false;

            if (slot == PartSlot.Torso)
            {
                sprite = _torso;
                return sprite != null;
            }

            var sprites = GetPartArray(slot);
            if (sprites == null || partId >= sprites.Length)
                return false;

            sprite = sprites[partId];
            return sprite != null;
        }

        public Sprite ResolveSprite(
            PartSlot slot,
            byte partId,
            BodyHeight height,
            bool broadShoulders)
        {
            Sprite source;
            if (slot == PartSlot.Torso)
            {
                source = _torso;
            }
            else if (!TryGetPart(slot, partId, out source))
            {
                return null;
            }

            if (source == null)
                return null;

            var applyShoulder = broadShoulders &&
                                PawnPartSlotRules.UsesShoulderMorph(slot);
            var applyHeight = height != BodyHeight.Default &&
                              PawnPartSlotRules.UsesHeightMorph(slot);
            if (!applyShoulder && !applyHeight)
                return source;

            if (_spriteVariantCache == null)
            {
                _spriteVariantCache =
                    new Dictionary<SpriteVariantKey, Sprite>();
            }

            var key = new SpriteVariantKey(
                source.GetInstanceID(),
                slot,
                height,
                broadShoulders);
            if (_spriteVariantCache.TryGetValue(key, out var cached) &&
                cached != null)
            {
                return cached;
            }

            var generated = CreatePixelPerfectVariant(
                source,
                slot,
                height,
                broadShoulders);
            if (generated == null)
                return source;

            _spriteVariantCache[key] = generated;
            return generated;
        }

        public string GetPartDisplayName(PartSlot slot, int index)
        {
            var sprite = GetPartSprite(slot, index);
            return sprite != null && !string.IsNullOrWhiteSpace(sprite.name)
                ? sprite.name
                : $"{GetSlotDisplayName(slot)} {index}";
        }

        public Vector2Int GetBodyOffset(
            BodyHeight height,
            ChannelId channel)
        {
            if (channel != ChannelId.Torso)
                return Vector2Int.zero;

            switch (height)
            {
                case BodyHeight.Short:
                    return new Vector2Int(0, -HeightPixelDelta);
                case BodyHeight.Tall:
                    return new Vector2Int(0, HeightPixelDelta);
                default:
                    return Vector2Int.zero;
            }
        }

        public Material ResolvePaletteMaterial(
            in PawnAppearance appearance)
        {
            if (_paletteMaterialTemplate == null)
                return null;

            if (_paletteMaterialCache == null)
            {
                _paletteMaterialCache =
                    new Dictionary<PaletteMaterialKey, Material>();
            }

            var normalized = appearance.WithVisibleColorDefaults();
            var key = new PaletteMaterialKey(
                normalized.SkinColor,
                normalized.HairColor,
                normalized.EyeColor);
            if (_paletteMaterialCache.TryGetValue(key, out var material) &&
                material != null)
            {
                return material;
            }

            material = new Material(_paletteMaterialTemplate)
            {
                name = $"PawnPalette_{key.GetHashCode():X8}",
                hideFlags = HideFlags.HideAndDontSave
            };
            ApplyPalette(material, normalized);
            _paletteMaterialCache[key] = material;
            return material;
        }

        public bool ValidateConfiguration(out string error)
        {
            if (_torso == null)
            {
                error = "기본 Torso Sprite가 비어 있습니다.";
                return false;
            }

            if (!HasAtLeastOneSprite(_legs))
            {
                error = "Legs 배열에 최소 1개의 Sprite가 필요합니다.";
                return false;
            }

            if (!HasAtLeastOneSprite(_heads))
            {
                error = "Heads 배열에 최소 1개의 Sprite가 필요합니다.";
                return false;
            }

            if (!HasAtLeastOneSprite(_eyes))
            {
                error = "Eyes 배열에 최소 1개의 Sprite가 필요합니다.";
                return false;
            }

            if (HasTooManyParts(_legs) ||
                HasTooManyParts(_heads) ||
                HasTooManyParts(_eyes) ||
                HasTooManyParts(_hairFronts) ||
                HasTooManyParts(_hairBacks) ||
                HasTooManyParts(_hats) ||
                HasTooManyParts(_tops) ||
                HasTooManyParts(_bottoms) ||
                HasTooManyParts(_shoes))
            {
                error = "각 파츠 배열은 byte ID 범위 때문에 255개를 넘길 수 없습니다.";
                return false;
            }

            error = string.Empty;
            return true;
        }

        public void ReleaseRuntimeCaches()
        {
            if (_paletteMaterialCache != null)
            {
                foreach (var pair in _paletteMaterialCache)
                    DestroyObject(pair.Value);
                _paletteMaterialCache.Clear();
            }

            if (_spriteVariantCache != null)
            {
                foreach (var pair in _spriteVariantCache)
                    DestroyObject(pair.Value);
                _spriteVariantCache.Clear();
            }

            if (_generatedTextures != null)
            {
                for (var index = 0; index < _generatedTextures.Count; index++)
                    DestroyObject(_generatedTextures[index]);
                _generatedTextures.Clear();
            }

            _unreadableWarnings?.Clear();
        }

        private Sprite[] GetPartArray(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.HairBack:
                    return _hairBacks;
                case PartSlot.Legs:
                    return _legs;
                case PartSlot.Bottom:
                    return _bottoms;
                case PartSlot.Shoes:
                    return _shoes;
                case PartSlot.Top:
                    return _tops;
                case PartSlot.Eyes:
                    return _eyes;
                case PartSlot.Head:
                    return _heads;
                case PartSlot.HairFront:
                    return _hairFronts;
                case PartSlot.Hat:
                    return _hats;
                default:
                    return null;
            }
        }

        private Sprite CreatePixelPerfectVariant(
            Sprite source,
            PartSlot slot,
            BodyHeight height,
            bool broadShoulders)
        {
            if (!TryReadSourcePixels(source, out var pixels))
                return null;

            var transformed = pixels;
            if (broadShoulders &&
                PawnPartSlotRules.UsesShoulderMorph(slot))
            {
                transformed = ExpandHorizontallyTwoPixels(transformed);
            }

            if (height == BodyHeight.Tall &&
                PawnPartSlotRules.UsesHeightMorph(slot))
            {
                transformed = ExtendLegsTwoPixels(transformed);
            }
            else if (height == BodyHeight.Short &&
                     PawnPartSlotRules.UsesHeightMorph(slot))
            {
                transformed = ShortenLegsTwoPixels(transformed);
            }

            var texture = new Texture2D(
                ExpectedCanvasSize,
                ExpectedCanvasSize,
                TextureFormat.RGBA32,
                false,
                false)
            {
                name = $"{source.name}_{slot}_{height}_" +
                       (broadShoulders ? "Broad" : "Default"),
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp,
                hideFlags = HideFlags.HideAndDontSave
            };
            texture.SetPixels32(transformed);
            texture.Apply(false, true);

            if (_generatedTextures == null)
                _generatedTextures = new List<Texture2D>();
            _generatedTextures.Add(texture);

            var sourceSize = source.rect.size;
            var pivot = new Vector2(
                source.pivot.x / Mathf.Max(1f, sourceSize.x),
                source.pivot.y / Mathf.Max(1f, sourceSize.y));
            var sprite = Sprite.Create(
                texture,
                new Rect(
                    0f,
                    0f,
                    ExpectedCanvasSize,
                    ExpectedCanvasSize),
                pivot,
                source.pixelsPerUnit,
                0,
                SpriteMeshType.FullRect,
                Vector4.zero);
            sprite.name = texture.name;
            sprite.hideFlags = HideFlags.HideAndDontSave;
            return sprite;
        }

        private bool TryReadSourcePixels(
            Sprite source,
            out Color32[] pixels)
        {
            pixels = null;
            if (source == null || source.texture == null)
                return false;

            Rect rect;
            try
            {
                rect = source.textureRect;
            }
            catch (UnityException)
            {
                WarnOnce(
                    source,
                    $"[{source.name}] 체형 자동 변형은 Full Rect Sprite만 " +
                    "지원합니다. Sprite Mesh Type을 Full Rect로 설정하십시오.");
                return false;
            }

            var width = Mathf.RoundToInt(rect.width);
            var height = Mathf.RoundToInt(rect.height);
            if (width != ExpectedCanvasSize ||
                height != ExpectedCanvasSize)
            {
                WarnOnce(
                    source,
                    $"[{source.name}] 체형 자동 변형은 {ExpectedCanvasSize}x" +
                    $"{ExpectedCanvasSize} Sprite만 지원합니다. 현재: " +
                    $"{width}x{height}");
                return false;
            }

            try
            {
                var texturePixels = source.texture.GetPixels32();
                var textureWidth = source.texture.width;
                var startX = Mathf.RoundToInt(rect.x);
                var startY = Mathf.RoundToInt(rect.y);
                pixels = new Color32[
                    ExpectedCanvasSize * ExpectedCanvasSize];

                for (var y = 0; y < ExpectedCanvasSize; y++)
                {
                    var sourceRow = (startY + y) * textureWidth + startX;
                    var targetRow = y * ExpectedCanvasSize;
                    Array.Copy(
                        texturePixels,
                        sourceRow,
                        pixels,
                        targetRow,
                        ExpectedCanvasSize);
                }

                return true;
            }
            catch (UnityException)
            {
                WarnOnce(
                    source,
                    $"[{source.name}] 키·어깨 자동 픽셀 변형을 사용하려면 " +
                    "Texture Import Settings의 Read/Write를 켜야 합니다.");
                return false;
            }
        }

        private static Color32[] ExpandHorizontallyTwoPixels(
            Color32[] source)
        {
            var result = new Color32[source.Length];
            var leftBoundary = ShoulderCenterX - 1;
            var rightBoundary = ShoulderCenterX;

            for (var y = 0; y < ExpectedCanvasSize; y++)
            {
                var row = y * ExpectedCanvasSize;
                for (var x = 0; x < ExpectedCanvasSize; x++)
                {
                    int sourceX;
                    if (x < leftBoundary)
                        sourceX = x + 1;
                    else if (x == leftBoundary)
                        sourceX = leftBoundary;
                    else if (x == rightBoundary)
                        sourceX = rightBoundary;
                    else
                        sourceX = x - 1;

                    result[row + x] = source[row + sourceX];
                }
            }

            return result;
        }

        private static Color32[] ExtendLegsTwoPixels(Color32[] source)
        {
            var result = new Color32[source.Length];
            for (var y = 0; y < ExpectedCanvasSize; y++)
            {
                int sourceY;
                if (y < LegStretchCenterY)
                    sourceY = y;
                else if (y < LegStretchCenterY + HeightPixelDelta)
                    sourceY = LegStretchCenterY;
                else
                    sourceY = y - HeightPixelDelta;

                CopyRow(source, sourceY, result, y);
            }

            return result;
        }

        private static Color32[] ShortenLegsTwoPixels(Color32[] source)
        {
            var result = new Color32[source.Length];
            for (var y = 0; y < ExpectedCanvasSize; y++)
            {
                var sourceY = y < LegStretchCenterY
                    ? y
                    : y + HeightPixelDelta;
                if (sourceY >= ExpectedCanvasSize)
                    continue;

                CopyRow(source, sourceY, result, y);
            }

            return result;
        }

        private static void CopyRow(
            Color32[] source,
            int sourceY,
            Color32[] target,
            int targetY)
        {
            Array.Copy(
                source,
                sourceY * ExpectedCanvasSize,
                target,
                targetY * ExpectedCanvasSize,
                ExpectedCanvasSize);
        }

        private void ApplyPalette(
            Material material,
            in PawnAppearance appearance)
        {
            SetTriplet(
                material,
                SkinShadowId,
                SkinBaseId,
                SkinHighlightId,
                appearance.SkinColor);
            SetTriplet(
                material,
                HairShadowId,
                HairBaseId,
                HairHighlightId,
                appearance.HairColor);
            SetTriplet(
                material,
                EyeShadowId,
                EyeBaseId,
                EyeHighlightId,
                appearance.EyeColor);
        }

        private void SetTriplet(
            Material material,
            int shadowId,
            int baseId,
            int highlightId,
            Color32 baseColor)
        {
            if (material.HasProperty(shadowId))
            {
                material.SetColor(
                    shadowId,
                    ScaleColor(baseColor, _shadowMultiplier));
            }

            if (material.HasProperty(baseId))
                material.SetColor(baseId, baseColor);

            if (material.HasProperty(highlightId))
            {
                material.SetColor(
                    highlightId,
                    ScaleColor(baseColor, _highlightMultiplier));
            }
        }

        private static Color ScaleColor(Color32 color, float multiplier)
        {
            return new Color(
                Mathf.Clamp01(color.r / 255f * multiplier),
                Mathf.Clamp01(color.g / 255f * multiplier),
                Mathf.Clamp01(color.b / 255f * multiplier),
                1f);
        }

        private void WarnOnce(Sprite source, string message)
        {
            if (_unreadableWarnings == null)
                _unreadableWarnings = new HashSet<int>();

            var id = source.GetInstanceID();
            if (_unreadableWarnings.Add(id))
                Debug.LogWarning(message, source);
        }

        private static bool HasAtLeastOneSprite(Sprite[] sprites)
        {
            if (sprites == null)
                return false;

            for (var index = 0; index < sprites.Length; index++)
            {
                if (sprites[index] != null)
                    return true;
            }

            return false;
        }

        private static bool HasTooManyParts(Sprite[] sprites)
        {
            return sprites != null && sprites.Length > byte.MaxValue;
        }

        private static string GetSlotDisplayName(PartSlot slot)
        {
            switch (slot)
            {
                case PartSlot.HairBack:
                    return "뒷머리";
                case PartSlot.Legs:
                    return "하체";
                case PartSlot.Bottom:
                    return "하의";
                case PartSlot.Shoes:
                    return "신발";
                case PartSlot.Torso:
                    return "상체";
                case PartSlot.Top:
                    return "상의";
                case PartSlot.Eyes:
                    return "눈동자";
                case PartSlot.Head:
                    return "머리";
                case PartSlot.HairFront:
                    return "앞머리";
                case PartSlot.Hat:
                    return "모자";
                default:
                    return slot.ToString();
            }
        }

        private static void DestroyObject(UnityEngine.Object target)
        {
            if (target == null)
                return;

            if (Application.isPlaying)
                Destroy(target);
            else
                DestroyImmediate(target);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            ReleaseRuntimeCaches();
        }
#endif

        private void OnDisable()
        {
            ReleaseRuntimeCaches();
        }

        private readonly struct PaletteMaterialKey :
            IEquatable<PaletteMaterialKey>
        {
            private readonly Color32 _skin;
            private readonly Color32 _hair;
            private readonly Color32 _eye;

            public PaletteMaterialKey(
                Color32 skin,
                Color32 hair,
                Color32 eye)
            {
                _skin = skin;
                _hair = hair;
                _eye = eye;
            }

            public bool Equals(PaletteMaterialKey other)
            {
                return _skin.Equals(other._skin) &&
                       _hair.Equals(other._hair) &&
                       _eye.Equals(other._eye);
            }

            public override bool Equals(object obj)
            {
                return obj is PaletteMaterialKey other && Equals(other);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    var hash = 17;
                    hash = hash * 31 + _skin.GetHashCode();
                    hash = hash * 31 + _hair.GetHashCode();
                    hash = hash * 31 + _eye.GetHashCode();
                    return hash;
                }
            }
        }

        private readonly struct SpriteVariantKey :
            IEquatable<SpriteVariantKey>
        {
            private readonly int _sourceId;
            private readonly PartSlot _slot;
            private readonly BodyHeight _height;
            private readonly bool _broad;

            public SpriteVariantKey(
                int sourceId,
                PartSlot slot,
                BodyHeight height,
                bool broad)
            {
                _sourceId = sourceId;
                _slot = slot;
                _height = height;
                _broad = broad;
            }

            public bool Equals(SpriteVariantKey other)
            {
                return _sourceId == other._sourceId &&
                       _slot == other._slot &&
                       _height == other._height &&
                       _broad == other._broad;
            }

            public override bool Equals(object obj)
            {
                return obj is SpriteVariantKey other && Equals(other);
            }

            public override int GetHashCode()
            {
                unchecked
                {
                    var hash = _sourceId;
                    hash = hash * 397 ^ (int)_slot;
                    hash = hash * 397 ^ (int)_height;
                    hash = hash * 397 ^ (_broad ? 1 : 0);
                    return hash;
                }
            }
        }
    }
}
